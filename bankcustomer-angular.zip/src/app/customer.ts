
export class Customer {
    
  
    constructor(
      public  id: number,
      public name: string,
      public age: number,
      public typeofAccount: string,
      public address: string,
      public active: boolean
     
    ){}
  }
  